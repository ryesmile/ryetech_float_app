package com.example.floatingapps;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, appList; EditText search; TextView permission; ArrayList<AppItem> all = new ArrayList<>();
    int purple = Color.rgb(103,80,164);
    @Override public void onCreate(Bundle b){ super.onCreate(b); build(); loadApps(); }
    @Override protected void onResume(){ super.onResume(); if(permission!=null) updatePermission(); }

    GradientDrawable bg(int color,float r){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(r); return g; }
    TextView tv(String s,float size,int color){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); return t; }
    int dp(int n){ return (int)(n*getResources().getDisplayMetrics().density+.5f); }

    void build(){
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(18),dp(18),dp(18),dp(28)); root.setBackgroundColor(Color.rgb(248,247,251)); scroll.addView(root); setContentView(scroll);
        LinearLayout header=new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL); TextView title=tv("Floating Apps",28,Color.rgb(35,32,40)); title.setTypeface(null,1); header.addView(title,new LinearLayout.LayoutParams(0,dp(50),1));
        TextView settings=tv("⋮",30,Color.DKGRAY); settings.setGravity(Gravity.CENTER); settings.setPadding(dp(10),0,dp(10),0); settings.setOnClickListener(v->showMenu(settings)); header.addView(settings,new LinearLayout.LayoutParams(dp(50),dp(50))); root.addView(header);
        TextView sub=tv("Keep your favorite apps one tap away.",15,Color.DKGRAY); root.addView(sub,new LinearLayout.LayoutParams(-1,dp(34)));

        LinearLayout permCard=new LinearLayout(this); permCard.setGravity(Gravity.CENTER_VERTICAL); permCard.setPadding(dp(14),dp(10),dp(10),dp(10)); permCard.setBackground(bg(Color.WHITE,dp(18))); permission=tv("",14,Color.DKGRAY); permCard.addView(permission,new LinearLayout.LayoutParams(0,dp(60),1)); Button grant=new Button(this); grant.setText("Allow"); grant.setAllCaps(false); grant.setOnClickListener(v->openOverlay()); permCard.addView(grant,new LinearLayout.LayoutParams(dp(82),dp(52))); root.addView(permCard,new LinearLayout.LayoutParams(-1,dp(82))); updatePermission();

        LinearLayout bar=new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(0,dp(16),0,dp(10)); search=new EditText(this); search.setHint("Search installed apps"); search.setSingleLine(); search.setPadding(dp(16),0,dp(12),0); search.setBackground(bg(Color.WHITE,dp(16))); search.addTextChangedListener(new android.text.TextWatcher(){ public void beforeTextChanged(CharSequence s,int a,int c,int d){} public void onTextChanged(CharSequence s,int a,int b,int c){filter(s.toString());} public void afterTextChanged(android.text.Editable e){} }); bar.addView(search,new LinearLayout.LayoutParams(0,dp(54),1)); root.addView(bar);
        TextView section=tv("ALL APPS",12,Color.GRAY); section.setTypeface(null,1); section.setPadding(dp(4),dp(6),0,dp(8)); root.addView(section);
        appList=new LinearLayout(this); appList.setOrientation(LinearLayout.VERTICAL); root.addView(appList);
        TextView foot=tv("Tip: drag the floating bubble anywhere on screen. Tap it to reopen the selected app.",13,Color.GRAY); foot.setPadding(dp(4),dp(20),dp(4),0); root.addView(foot);
    }
    void updatePermission(){ if(permission==null)return; boolean ok=Settings.canDrawOverlays(this); permission.setText(ok?"✓ Floating permission enabled\nYou can launch apps with a floating bubble.":"Display over other apps is required\nAllow it to use the floating bubble."); permission.setTextColor(ok?Color.rgb(45,110,65):Color.rgb(80,75,85)); }
    void openOverlay(){ if(!Settings.canDrawOverlays(this)) startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()))); }
    void loadApps(){ all.clear(); Intent q=new Intent(Intent.ACTION_MAIN); q.addCategory(Intent.CATEGORY_LAUNCHER); List<ResolveInfo> infos=getPackageManager().queryIntentActivities(q,0); Collections.sort(infos,(a,b)->String.valueOf(a.loadLabel(getPackageManager())).compareToIgnoreCase(String.valueOf(b.loadLabel(getPackageManager())))); for(ResolveInfo r:infos){if(!r.activityInfo.packageName.equals(getPackageName())) all.add(new AppItem(String.valueOf(r.loadLabel(getPackageManager())),r.activityInfo.packageName,r.loadIcon(getPackageManager())));} filter(""); }
    void filter(String q){ if(appList==null)return; appList.removeAllViews(); String x=q.toLowerCase(Locale.ROOT); int count=0; for(AppItem a:all){if(!a.name.toLowerCase(Locale.ROOT).contains(x))continue; appList.addView(card(a)); count++;} if(count==0){TextView e=tv("No matching apps",15,Color.GRAY); e.setGravity(Gravity.CENTER); appList.addView(e,new LinearLayout.LayoutParams(-1,dp(100)));}}
    View card(AppItem a){ LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(12),dp(8),dp(10),dp(8)); row.setBackground(bg(Color.WHITE,dp(18))); LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(76)); rp.setMargins(0,dp(4),0,dp(4));
        ImageView icon=new ImageView(this); icon.setImageDrawable(a.icon); row.addView(icon,new LinearLayout.LayoutParams(dp(48),dp(48))); LinearLayout texts=new LinearLayout(this); texts.setOrientation(LinearLayout.VERTICAL); texts.setGravity(Gravity.CENTER_VERTICAL); texts.setPadding(dp(12),0,dp(6),0); TextView n=tv(a.name,16,Color.rgb(35,32,40)); n.setTypeface(null,1); texts.addView(n); TextView p=tv(a.pkg,11,Color.GRAY); texts.addView(p); row.addView(texts,new LinearLayout.LayoutParams(0,-1,1)); Button launch=new Button(this); launch.setText("Float"); launch.setAllCaps(false); launch.setTextColor(Color.WHITE); launch.setBackground(bg(purple,dp(18))); launch.setOnClickListener(v->launch(a.pkg)); row.addView(launch,new LinearLayout.LayoutParams(dp(82),dp(48))); row.setOnClickListener(v->launch(a.pkg)); return row; }
    void launch(String pkg){ if(!Settings.canDrawOverlays(this)){openOverlay(); return;} Intent l=getPackageManager().getLaunchIntentForPackage(pkg); if(l!=null){l.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(l); Intent s=new Intent(this,FloatingBubbleService.class); s.putExtra("package",pkg); if(Build.VERSION.SDK_INT>=26)startForegroundService(s);else startService(s);} }
    void showMenu(View anchor){ PopupMenu p=new PopupMenu(this,anchor); p.getMenu().add("Refresh app list"); p.getMenu().add("Open overlay settings"); p.getMenu().add("About"); p.setOnMenuItemClickListener(i->{String s=i.getTitle().toString(); if(s.startsWith("Refresh"))loadApps(); else if(s.startsWith("Open"))openOverlay(); else Toast.makeText(this,"Floating Apps v2",Toast.LENGTH_SHORT).show(); return true;}); p.show(); }
    static class AppItem{String name,pkg; android.graphics.drawable.Drawable icon; AppItem(String n,String p,android.graphics.drawable.Drawable i){name=n;pkg=p;icon=i;}}
}
